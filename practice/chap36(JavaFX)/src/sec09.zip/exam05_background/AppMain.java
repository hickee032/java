package sec09.exam05_background;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class AppMain extends Application {
	@Override
	public void start(Stage primaryStage) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("root.fxml"));
			
		Scene scene = new Scene(root);		
		//�ܺο��� �ۼ��� CSS������ Scene�� �����Ѵ�.
		scene.getStylesheets().add(getClass().getResource("app.css").toString());
		
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setTitle("AppMain");		
		//primaryStage.setOnCloseRequest(event -> System.out.println("���� Ŭ��"));		
	}	
	public static void main(String[] args) {
		Application.launch(args);
	}

}
