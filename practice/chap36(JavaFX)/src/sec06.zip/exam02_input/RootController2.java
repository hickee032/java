package sec06.exam02_input;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class RootController2 implements Initializable {

	@FXML
	private TextField txtTitle;
	@FXML
	private PasswordField txtPassword;
	@FXML
	private TextArea txtContent;
	@FXML
	private DatePicker dateExit;
	@FXML
	private ComboBox<?> comboPublic;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

	}

	public void handleBtnRegAction(ActionEvent event) {

		System.out.println("����: " + txtTitle.getText());
		System.out.println("���� ����: " + comboPublic.getValue());
		System.out.println("�Խ� ������: " + dateExit.getValue());
		System.out.println("���� : " + txtContent.getText());

	}

	public void handleBtnCancelAction(ActionEvent event) {
		Platform.exit();
	}

}
