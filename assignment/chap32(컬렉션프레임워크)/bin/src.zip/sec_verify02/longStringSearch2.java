package sec_verify02;

public class longStringSearch2 {

}