package sec_verify02;

public class StringSearchExample {

	public static void main(String[] args) {
		longStringSearch lo = new longStringSearch(0);

	}

}
