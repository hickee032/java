package sec_verify.exam05;

public class Main {
	
	public static void main(String[] args) {		
		new Plate4x4Frame("");
	}
}
