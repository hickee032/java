package sec_verify.exam07_1;

public class Main {

	public static void main(String[] args) {
		
		new BingGoGame();

	}

}
