package Assignment_Array01;

import java.util.Scanner;

public class Assignment14_Month {

	public static void main(String[] args) {
		
		int [] day = new int []{31,28,31,30,31,30,31,31,30,31,30,31};
		
		Scanner scan = new Scanner(System.in);
		
		for (int i = 0 ; i <= 12 ; ) {
				
			System.out.print("�� �Է� : ");
			
			int month = scan.nextInt();
					
			
			System.out.println(month + "���� " +day[month-1] +"�� �Դϴ�." );
			
			break;
				
				}
		
				scan.close();	
		}

	}

	