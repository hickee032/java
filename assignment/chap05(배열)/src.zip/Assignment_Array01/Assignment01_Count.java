package Assignment_Array01;
import java.util.Scanner;

public class Assignment01_Count {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		System.out.print("�迭�� �Է� : ");
		int count = scan.nextInt();
	
		int[] num = new int[count];
		
		for(int i =0; i<count; i++) {
		
		System.out.println("num["+i+"]"+"="+num[i]);

	}
		scan.close();
	}
}
