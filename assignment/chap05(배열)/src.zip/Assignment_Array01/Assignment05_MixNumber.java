package Assignment_Array01;

import java.util.Arrays;

public class Assignment05_MixNumber {

	public static void main(String[] args) {

		int [] arr = new int [10];
		
		for (int i =0 ; i<10 ; i++) {
			
			arr[i] = i;
			}			
			System.out.println(Arrays.toString(arr));
		
		for (int i =0 ; i<arr.length ; i++) {
			
			int n = (int)(Math.random()*10);
			
			int tmp = arr[0];
			arr[0] = arr[n];
			arr[n] = tmp;
			
			}
			System.out.println(Arrays.toString(arr));
		}
	
	}


