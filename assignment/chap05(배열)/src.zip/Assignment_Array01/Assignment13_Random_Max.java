package Assignment_Array01;

import java.util.Arrays;

public class Assignment13_Random_Max {

	public static void main(String[] args) {
		

		int num = 0;
		int max = 0;
		 
		int [] Random = new int [100];
		
		for (int i = 0 ; i < 100 ; i++) {
			
			Random[i] = (int)(Math.random()*10);
			
			}
 
	
		for (int i = 0 ;  i<10 ; i++) {
				if(Random[max]<Random[i]) {
					max=i;
					Random[i]
					
					
				}
			//if(Random[r]>Random[i]) {
			}	
			}

	

}
