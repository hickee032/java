package Assignment_Array01;

import java.util.Scanner;

public class Assignment12_Score {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		int [] score = null;
		
		boolean start= true; 
		
		int sum = 0;
		int max = 0;
		

		

		while(start) {
			
			System.out.println("------------------------------------------------------------");
			System.out.println("      1.�л��� | 2.�����Է� | 3.��������Ʈ | 4.�м� | 5.����                   ");
			System.out.println("------------------------------------------------------------");
			
	
			System.out.print("����> ");
			int number = scan.nextInt();
				
			
				if(number==1) {
					System.out.print("�л���>");
					
					int people= scan.nextInt();
					
					score = new int [people];
		
						}
				else if(number==2) {
					
					 System.out.println("���� >");
						
					    for (int i=0 ; i<score.length ; i++) {
					    	
					    	System.out.print("scores[" + i + "] = ");
					    	
					    	score[i] = scan.nextInt();
					    	}}
				else if(number==3) {
					   for (int i=0 ; i<score.length ; i++) {
						   	System.out.println("scores[" + i + "]: " + score[i]);	
					    	}
							}
				else if(number==4) {			
					    	for (int i=0 ; i<score.length ; i++) {
					    					    			                         
					    		 max = score[0];
					    		 sum += score[i];	
					    		 
							     	if (score[i]>=max) {						    	
							     			max=score[i]; }
							     	
							    
							     				    				
							      }
	                        double avg = (double)(sum/score.length);
				    		System.out.println("��� : " + avg);
				    		System.out.println("max "+max);	
				    		

					    	
					    		}
				else if(number==5) { 
					System.out.println("����");
					start = false;
					
				}
			}
		scan.close();}
	}
	

						    	
    
	
							
				

		

	


