package Assignment_Array01;

import java.util.Scanner;

public class Assignment11_1_369 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		System.out.println("3,6,9 ���������� �մϴ�.");
		System.out.print("����� �����ұ��?  :");
		
		int input = scan.nextInt();
		int [] score = new int [input];
		
		for( int i =0; i < score.length; i++ ) {	
			
			score[i] = i;
			
			
		for (int sam = 10 ; sam < score.length  ; sam++ ) {	
					
			if(10 < score[i]/3){
				if(score[i]%3==0){
					
					System.out.println(score[i]+ "�ڼ� �ι�");
				break;
				}}
				
			int	a = score[i]%10;
			if((a==3 || a==6 || a==9)||(score[i]/10==3 || score[i]/10==6 || score[i]/10==9)) {
					  System.out.println(score[i]+"�ڼ� �ѹ�");
					  break;}
				
			
			//if (score[i]/10==3 || score[i]/10==6 || score[i]/10==9) {
				//System.out.println(score[i]+ "�ڼ� �ι�");}
			
			/*
			 * if((score[i]/3==3 && score[i]/3==6 && score[i]/3==9)) {
			 * System.out.println(score[i]+"�ڼ� �ι�");}
			 */
			}
			}
		
		scan.close();}
}
