package Assignment_Array01;

import java.util.Scanner;

public class Assignment09_Money01 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner (System.in);
		
		int money = scan.nextInt();
				
		String [] a = new String [] {"50000", "10000", "5000","1000","100", "50", "10", "5", "1"};
		
		int [] coin = new int [9];
		
		int man_5 = 0;
		int man_1 = 0;
		int che_5 = 0;
		int che_1 = 0;
		int bek_5 = 0;
		int bek_1 = 0;
		int ten_5 = 0;
		int ten_1 = 0;
		int won_5 = 0;
		int won_1 = 0;
		
		for (int i = 0 ; i < a.length ; i++) {
			
		 coin[i] = Integer.parseInt(a[i]);
		}
		
		man_5 = money / 50000;
		man_1 = money % 50000 / 10000; 
		che_5 = money % 50000 % 10000 /5000; 
		che_1 = money % 50000 % 10000 %5000 / 1000; 
		bek_5 = money % 50000 % 10000 %5000 % 1000 / 500; 
		bek_1 = money % 50000 % 10000 %5000 % 1000 % 500 / 100; 
		ten_5 = money % 50000 % 10000 %5000 % 1000 % 500 % 100 / 50; 
		ten_1 = money % 50000 % 10000 %5000 % 1000 % 500 % 100 % 50 / 10; 
		won_5 = money % 50000 % 10000 %5000 % 1000 % 500 % 100 % 50 % 10 / 5;
		won_1 = money % 50000 % 10000 %5000 % 1000 % 500 % 100 % 50 % 10 % 5 /1;
		
		
		System.out.println("5������ "+man_5+"��");
		System.out.println("1������ "+man_1+"��");
		System.out.println("5õ���� "+che_5+"��");
		System.out.println("1õ���� "+che_1+"��");
		System.out.println("5����� "+bek_5+"��");
		System.out.println("1����� "+bek_1+"��");
		System.out.println("5�ʿ��� "+ten_5+"��");
		System.out.println("1�ʿ��� "+ten_1+"��");
		System.out.println("5���� "+won_5+"��");
		System.out.println("1���� "+won_1+"��");
		
		scan.close();
	}

}
