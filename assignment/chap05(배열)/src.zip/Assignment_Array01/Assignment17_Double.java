package Assignment_Array01;

public class Assignment17_Double {

	public static void main(String[] args) {
		
		double [] arr = new double [] {1.1, 2.2, 6.6, 4.4, 5.5, 4.4, 3.3, 4.4, 2.2, 3.3};
		
		double [] gc = new double [10];
		
		for (int i = 0 ; i <arr.length ; i++) {
			if (arr[i]==arr[i+1]) {
			
				
				System.out.println(arr[i]);
				System.out.println("--------------");
				System.out.println(gc[i]);
			}
			
		}
		

	}

}
