package Assignment_Array01;

import java.util.Scanner;

public class Assignment09_Money {

	public static void main(String[] args) {

		Scanner scan = new Scanner (System.in);
		
		String[] a = new String[]{"50000", "10000", "5000","1000","100", "50", "10", "5", "1"};
		
		System.out.println("�ݾ��� �Է��Ͻÿ�>> ");
		int cost = scan.nextInt();
		
		for (int i = 0; i<cost;i++ ) {
			for (int five = 0; five<cost; ) {
				
				int j = Integer.parseInt(a[0]);
				
					int money_50 = cost/j; 
					int change_50 = cost%j;
					
				System.out.println("50000���� " + money_50 +"��");
				System.out.println(change_50); 	
				
					for (int k = 0; k<50000;) {
						
						int l = Integer.parseInt(a[1]);
						
						int money_10 = change_50/l; 
						int change_10 = change_50%l;
						
						System.out.println("10000���� " + money_10 +"��");
						System.out.println(change_10);
						
						/* for (int m = 0 ; m<10000;) {
							 	int money_5 = change_10/l; 
								int change_5 = change_10%l;
								
								System.out.println("10000���� " + money_10 +"��");
								System.out.println(change_10);
								*/
						 }
					} scan.close();
				}
		}
	}

			
		
					
