package Assignment_Array01;

import java.util.Scanner;

public class Assignment09_Money02 {

	public static void main(String[] args) {

		Scanner scan = new Scanner (System.in);
		
		String [] a = new String [] {"50000", "10000", "5000","1000","100", "50", "10", "5", "1"};

		int [] coin = new int [a.length];
		
		System.out.print("�ݾ��� �Է��ϼ��� : ");
		int money = scan.nextInt();
		
		for (int i = 0; i <a.length; i++) {
			
			coin[i] = Integer.parseInt(a[i]);
			System.out.println(coin[i] +"��"+ money / coin[i]);
			money%= coin[i];
							}
		scan.close();}
}
		
	
		
	


