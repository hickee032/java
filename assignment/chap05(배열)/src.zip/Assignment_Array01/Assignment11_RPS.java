package Assignment_Array01;

import java.util.Scanner;

public class Assignment11_RPS {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		String [] str = new String [] {"����", "����", "��", "�׸�"};
		
		boolean run = true;
		
		while(run) {
			
			System.out.println("���� ���� ���� �Է�");
			//System.out.println("�Է� : ");
			
			//String com = str[(int)(Math.random()*3)];
			//String you = scan.nextLine();
			String com = str[(int)(Math.random()*3)];
			
			//System.out.println(com);
			System.out.print("�Է� : ");
			
			
			String you = scan.nextLine();
	
			///////////////////////////////////////////////		
			if (you.equals(str[0])) {
				
				System.out.println("�����ϴ�."); 
						continue;
						}
				if (com.equals(str[1])) {
						System.out.println("�����ϴ�."); 
						continue;
						}
				else if (com.equals(str[2])) {
						System.out.println("�̰���ϴ�."); 
						continue;
						}
			////////////////////////////////////////////////////////
				if (you.equals(str[1])) {
					
					System.out.println("�����ϴ�."); 
							continue;
							}
					if (com.equals(str[2])) {
							System.out.println("�����ϴ�."); 
							continue;
							}
					else if (com.equals(str[0])) {
							System.out.println("�̰���ϴ�."); 
							continue;
							}
			/////////////////////////////////////////////////////////
					if (you.equals(str[2])) {
						
						System.out.println("�����ϴ�."); 
								continue;
								}
						if (com.equals(str[1])) {
								System.out.println("�����ϴ�."); 
								continue;
								}
						else if (com.equals(str[0])) {
								System.out.println("�̰���ϴ�."); 
								continue;
								}		
				///////////////////////////////////////////////////////
						
							//System.exit();
						
						if (you.equals(str[3])) {
							System.out.println("����");
							
							run = false;
							}					
	}
							scan.close();}
}		




