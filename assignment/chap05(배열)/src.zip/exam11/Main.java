package sec_verify.exam11;

public class Main {

	public static void main(String[] args) {
		BouncingBall bc = new BouncingBall("Bouncing Ball");
		bc.start();
	}
}
