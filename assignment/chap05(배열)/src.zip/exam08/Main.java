package sec_verify.exam08;

public class Main {

	public static void main(String[] args) {
		
		Timer timer = new Timer();
		timer.start();
	}
}
