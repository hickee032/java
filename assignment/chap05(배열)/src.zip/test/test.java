package test;

import java.util.Scanner;

public class test {

   public static void main(String[] args) {
      
      Scanner sc = new Scanner(System.in);      
      System.out.print("��Ҽ� �Է�:");
      int num = sc.nextInt();
            
      int[][] score = new int[num][10];
      
      for(int i=0; i<num; i++) {
         
         int ran = (int)(Math.random()*10);
         
         for(int j=0; j<ran; j++) {
            score[i][j] = 1;
         }
         
      }
      
      for(int i=9; i>=0; i--) {
         
         for(int j=0; j<num; j++) {
            
            if(score[j][i]==1) {
               System.out.print("*\t");
            } else {
               System.out.print("" + "\t");
            }
               
            
         }
         System.out.println();
         if(i==0) {
            for(int j=0; j<num; j++) {
               System.out.print("-" + "\t");
            }
            System.out.println();
            for(int j=0; j<num; j++) {
               System.out.print(j + "\t");
            }
         }
         
      }
      
      
      
      sc.close();

   }

}