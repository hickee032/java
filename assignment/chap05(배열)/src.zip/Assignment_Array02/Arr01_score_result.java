package Assignment_Array02;

public class Arr01_score_result {

	public static void main(String[] args) {
					
		int [][] score = new int[][] {
			{100, 100, 100},
			{20, 20, 20,},
			{30, 30, 30},
			{40, 40, 40},
			{50, 50, 50}
									};		
									
		int a = 0;
		int b = 0;
		int c = 0;
					
		int sum = 0;
		
	for(int i =0 ; i < score.length ; i++) {
		
		int tosum = 0;
		
		a += score[i][0];
		b += score[i][1];
		c += score[i][2];
		
		//result �迭 ����
		int [][] result = new int [score.length][score[i].length]; 
		
		for (int j =0; j<score[i].length; j++) {
			
			sum +=score[i][j];
			
			System.arraycopy(score, 0, result, 0, score.length);  //�迭�� ����
			
			//int [] sum = new int [score[i].length]; 									
			
			System.out.printf("\t%d", result[i][j]);		
		}
		 	tosum += sum;
		 	System.out.printf("\t%d", sum);
	}
	}

}
