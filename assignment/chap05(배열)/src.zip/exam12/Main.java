package sec_verify.exam12;

public class Main {

	public static void main(String[] args) {
		new GamblingWithThread("");
	}
}
