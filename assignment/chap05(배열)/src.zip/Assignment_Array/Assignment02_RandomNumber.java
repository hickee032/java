package Assignment_Array;

import java.util.Scanner;

public class Assignment02_RandomNumber {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("��Ҽ� �Է� : ");
		
		int num = scan.nextInt();
		
		int [] arr = new int [num];
		
		for(int i = 0; i<num ;i++) {
		
			arr [i] = (int)(Math.random()*num);
		
		System.out.println("arr["+i+"]"+"="+arr [i]);
		}
		scan.close();
	}

}
