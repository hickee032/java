package Assignment_Array;

import java.util.Arrays;

public class Assignment08_ArrayMix {

	public static void main(String[] args) {
		
		int [] code = new int [] {-9, -55, 73, 116, 101, 205, 1000};
		int [] arr = new int [10];
		
		
		System.arraycopy(code, 0, arr, 0, 7);
		System.arraycopy(code, 0, arr, 7, 3);
		
		
		
		
		
		for  (int i=0; i<10 ; i++) {
			for(int j=0;j<arr.length-1;j++) {
				if(arr[j]<arr[j+1]) {
					int temp = arr[j];
					arr[j]  = arr[j+1];
					arr[j+1]= temp;
				}
			}			
		}
		System.out.println(Arrays.toString(arr));
		}
			
		
	}


