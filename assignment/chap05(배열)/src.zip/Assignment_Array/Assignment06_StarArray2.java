package Assignment_Array;

import java.util.Random;
import java.util.Scanner;

public class Assignment06_StarArray2 {

	public static void main(String[] args) {

		Random ram = new Random();
		Scanner scan = new Scanner(System.in);

		System.out.println("��Ҽ� �Է� : ");

		int num = scan.nextInt();

		int[] arr = new int[num];

		for (int i = 0; i < num; i++) {

			arr[i] = ram.nextInt(num) + 1;

			//System.out.print("arr[" + i + "] = ");
			
			
			System.out.print("arr[" + i + "] = ");
			for(int s = 0; s < arr[i] ; s++) {
				
				System.out.print("*");
					}  
					System.out.println();
					}
		 
		scan.close();
	}

}
