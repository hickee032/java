package Assignment_Array;


import java.util.Scanner;

public class Assignment10_MathRandomSort {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		System.out.print("��� �� : ");
		
		int b = scan.nextInt();
		
		int [] a = new int [b];
		
		
		
		for(int i=0 ; i<a.length ; i++) {
				a [i] = (int)(Math.random()*10+1);

				System.out.println("a["+i+"] = "+a[i]);}
		
		int temp = 0;
		int j = a.length-1;
		
		System.out.println("���� �迭�� ���� �����.");
		
		for (int i=0 ; i<a.length/2 ; i++,j--) {
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;	}
			for(int i=0;i<a.length;i++) {
						
		System.out.println("a["+i+"] = "+a[i]+"\t");}
			
		
			scan.close();
		}
	

}
	
	

		

 			
					




