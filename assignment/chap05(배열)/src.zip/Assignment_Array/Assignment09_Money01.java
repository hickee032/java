package Assignment_Array;

import java.util.Scanner;

public class Assignment09_Money01 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner (System.in);
		
		int money = scan.nextInt();
				
		String [] a = new String [] {"50000", "10000", "5000","1000","100", "50", "10", "5", "1"};
		
		for ( )

	}

}
