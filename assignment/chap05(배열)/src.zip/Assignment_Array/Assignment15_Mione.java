package Assignment_Array;

import java.util.Scanner;

public class Assignment15_Mione {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		
		int [] number = new int [100];
		
		
		for(int i=0; i<number.length; i++) {
			
			int input = scan.nextInt();
			
			number[i] = input;
			if (input == -1) {
				
				
				
			}
		}
		
		
		

	}

}
