package Assignment_Array;

import java.util.Scanner;

public class Assignment15_100_1 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		int count = 0;
		
		int [] number = new int [100];
		
		for (int i = 0 ; i < 100 ; i++) {
			
			System.out.println("���ϴ� ������ �Է��ϼ���" );
			number[i] = scan.nextInt();
			
			count++;
			
			if(number[i] == -1) {
				
				number[i] = number[count];
				
			System.out.print("������ �Է��� 3����");
			System.out.print(number[count-2]+ " ");
			System.out.print(number[count-3] + " ");
			System.out.print(number[count-4] + " ");
			System.out.print("�Դϴ�.");
			
			break;
			}
		}


		scan.close();}

}
