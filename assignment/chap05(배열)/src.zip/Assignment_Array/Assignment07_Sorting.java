package Assignment_Array;

public class Assignment07_Sorting {

	public static void main(String[] args) {

		int [] ball = new int[20];
		for (int i =0; i<20; i++) {
			ball[i] = i;
			System.out.println("ball["+i+"]"+"="+ball[i]); }
		
		for(int i=0;i<ball.length;i++) {
			for(int j=0;j<ball.length-1;j++) {
				if(ball[j]<ball[j+1]) {
					int temp = ball[j];
					ball[j]  = ball[j+1];
					ball[j+1]= temp;
			}
			}
		}
		
			System.out.println("------------");
			
		for(int i=0; i<5;i++) {
				
				
				System.out.println("ball["+i+"]"+"="+ball[i]); }

}
}
