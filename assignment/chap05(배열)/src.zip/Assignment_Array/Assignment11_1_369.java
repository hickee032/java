package Assignment_Array;

import java.util.Scanner;

public class Assignment11_1_369 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		System.out.println("3,6,9 ���������� �մϴ�.");
		System.out.print("����� �����ұ��?  :");
		
		int input = scan.nextInt();
		int [] score = new int [input];
		
		for( int i =0; i < input; i++ ) {	
			score[i] = i;
			
			if (score[i]/10==3 && score[i]/10==6 && score[i]/10==9) {
				System.out.println(score[i]+ "�ڼ� �ѹ�");}
			
			/*
			 * if((score[i]/3==3 && score[i]/3==6 && score[i]/3==9)) {
			 * System.out.println(score[i]+"�ڼ� �ι�");}
			 */
					}
			}
		
	}

	