package Assignment_Array;

import java.util.Arrays;
import java.util.Scanner;

public class Assignment03_ArrytoString_Count {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		System.out.print("��� �� �Է� : ");
		
		int arr = scan.nextInt();
		
		int[] num = new int [arr];
		
		for(int count =0; count<arr; count++) {
			
				System.out.print("num["+count+"]"+"=");

				num [count] = scan.nextInt();	
	
		}		
			System.out.print("num =" );
			System.out.println(Arrays.toString(num));	
			
			scan.close();

	}

}
