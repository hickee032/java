package sec_verify.exam09;

public class Main {

	public static void main(String[] args) {
		new CalendarEx("������");
	}
}
