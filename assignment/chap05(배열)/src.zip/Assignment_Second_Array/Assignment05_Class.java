package Assignment_Second_Array;

import java.util.Scanner;

public class Assignment05_Class {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int rooms = 0;
		int rooms_p = 0;
		
		int total_sum = 0;
		double total_avg = 0.0;
		
		//int sum = 0;
		//double avg =0.0;
		
		System.out.print("�ݼ��� : ");
		
		rooms = scan.nextInt();
		
		int [][] grade = new int [rooms][]; //�ݼ� �Է�
											//2�������� 1���� �迭�� ���� �ּ�
											//����ġ�۾� �ʿ�
		int[] sum = new int [grade.length];
		double[] avg = new double [grade.length];
		
		for (int i = 0 ; i < grade.length ; i++) {
			System.out.print((i+1) + "���� �ο� : ");
			
			rooms_p = scan.nextInt();
			//����ġ�۾�
			grade[i] = new int [rooms_p];
						
			for (int j = 0 ; j < grade[i].length ; j++) {
				
				System.out.print((i+1)+" ����" +(j+1)+" ���� ���� : ");
				
				int score = scan.nextInt();
				
				grade[i][j] = score;
				
	//==============================================================================	
	//				�� �� �κ��� �߿��ϴ�.
	//==============================================================================
				
				sum[i] += grade[i][j];
				avg[i] = (double)(sum[i]/grade[i].length);
				
	//==============================================================================			
				
			}	
			total_sum += sum[i];
			total_avg += avg[i]/2;
			
		}
		System.out.println( "��\t�հ�\t ���");
		System.out.println("---------------------");
		
		for (int i = 0 ; i < grade.length ; i++) {
			System.out.println((i+1) + "�� \t" + sum[i]+"\t" + avg[i]);
			//System.out.println(sum[i]);
		}
		System.out.println("---------------------");
		System.out.println("���� \t" + total_sum +"\t" + total_avg);
		
		

		scan.close();}		
}	

//10 10 10 i=0
//10 10

