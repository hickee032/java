package Assignment_Second_Array;

import java.util.Scanner;

public class Assignment01_Star {

	public static void main(String[] args) {		
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("��Ҽ� �Է�");
		
		int input = scan.nextInt();
		
		String [][] star = new String [input][10];
		
//---------------------------------------------------------------
		
		for(int i = 0 ; i < star.length ; i++) {
			
			int random = (int)(Math.random()*10);
	
			System.out.println();

			for (int j = 8 ; j <= random ; j-- ) {
				
				star[j][i] = "*";

				System.out.print(star[i][j]);
		
				}	
			
			}
		scan.close();}

}
