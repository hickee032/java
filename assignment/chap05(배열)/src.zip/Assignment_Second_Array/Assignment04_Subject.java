package Assignment_Second_Array;

import java.util.Scanner;

public class Assignment04_Subject {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		//���� & �ʱ�ȭ
		int kor = 0;
		int math = 0;
		
		double kor_avg = 0;
		double math_avg = 0;
		
		int [][] student = new int [6][2];
		
		double [] student_avg = new double [6];
		
		 for (int i = 0 ; i<student.length ; i++) {
			 
			 //�Է�
			 System.out.print(i+1 + " " + "�������� �Է� :");
	 			student[i][0] = scan.nextInt();
	 		
	 		 System.out.print(i+1 + " " + "�������� �Է� :");
	 			student[i][1] = scan.nextInt();	
	 		
	 		//�� ���� �ջ갪�� kor,math�� �����ϵ��� �Ѵ�.	
	 			kor += student[i][0];
	 			math += student[i][1];
	 			
	 			
			 
			 for (int j = 0 ; j <student[i].length ; j++) {	
			
				 student_avg[i] = (double)((student[0][j] + student[1][j])/student[i].length);
			 } 
		 }
		 
		 System.out.println("=====================");
		 

		 for (int i=0 ; i<student.length ; i++) {
			 
			 
			 //kor, eng�� ����� �����Ѵ�.
			 kor_avg = (double)(kor/student[i].length);
			 math_avg = (double)(math/student[i].length);  }
			 
			 System.out.println("���� = " + kor_avg);
			 System.out.println("���� = " + math_avg);
			 System.out.println("=====================");
			 
			 for (int i=0 ; i<student.length ; i++) {
				 System.out.println((i+1)+" ��� = " + student_avg[i]);
			 }	 
	 scan.close();			 
	 
	}

}
