package Assignment_Second_Array;

public class Assignment06_Sum_Avg {

	public static void main(String[] args) {
		
		int sum = 0;
		int b = 0;
		double avg = 0;

		int[][] array = { 
				{95, 86, 100, 55},
				{83, 92, 96},
				{78, 83, 93, 87, 88, 77, 10}
			};
		

		
		for(int i =0 ;  i<array.length ; i++) {
			
			b += array[i].length;
			
			for(int j = 0; j<array[i].length ; j++) {
				
				sum += array[i][j];	
		
			}
			
			//System.out.println(sum);	
			avg = (double)sum/b;
		}
			
			System.out.println("�� �����迭�� �հ�(sum) : " + sum);
			System.out.printf("�� �����迭�����(avg) : " + "%.1f",avg);

	}

}
