package Assignment_Second_Array;

import java.util.Scanner;

public class Ptr {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);

		int i = 0;
		int j = 0;
		
		int random = 0;

		System.out.print("��Ҽ� �Է�");

		int input = scan.nextInt();

		String[][] star = new String[input][10];   //�Է� & ���� & �ʱ�ȭ

//---------------------------------------------------------------

		for( i=0; i<star.length; i++) {
			random = (int)(Math.random()*10);
			for( j=0; j<=random; j++) {
				star[i][j] =" ";
			}
		}

		for( i = 9; i>=0; i--) {
			for( j =0; j<star.length; j++) {
				if(star[j][i]==" ") {
					System.out.printf("%s\t", "*");
				}
//				else {
//					System.out.printf("%s\t", " ");
//				}
			}
			System.out.println();
		}
		
//---------------------------------------------------------------		
		
		for (i = 0; i < star.length; i++) {
			System.out.printf("%s\t", "-");
		}
		System.out.println();
		for (i = 0; i < star.length; i++) {
			System.out.printf("%d\t", i);
		}                                          //���
		scan.close();}
}
