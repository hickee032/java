package Assignment_Second_Array;

import java.util.Scanner;

public class ptr02 {

	public static void main(String[] args) {

		int i = 0;
		int j = 0;

		Scanner scan = new Scanner(System.in);

		System.out.println("��Ҽ� �Է�");

		int input = scan.nextInt();

		int [][] star = new int [10][input];

/*--------------------------------------------------------------------------------*/
		for ( i = 0; i < star[i].length; i++) {
			
			//star[i][0] = i;
			
			System.out.println();
			
			for ( j = 0 ; j < star[i].length ; j++ ) {
				
					if (i>=j) {
						
						star[i][j] = 1;
												
					}
				
					System.out.print(star[i][j]);
				
			}
			
		}
	}

}
