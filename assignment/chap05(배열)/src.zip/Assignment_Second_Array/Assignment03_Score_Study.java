package Assignment_Second_Array;

public class Assignment03_Score_Study {

	public static void main(String[] args) {

		int[][] score = {
			  			{ 88, 95, 100},
			  			{ 85, 63, 20},
			  			{ 34, 30, 30},
			  			{ 40, 49, 70},
			  			{ 15, 75, 98},
										};
		
		//int [][] result = new int [score.length+2][score.length];
		
		int kor = 0;
		int eng = 0;
		int math = 0;
		
		
		System.out.println("��ȣ     ����      ����       ����       ����       ���");
		System.out.println("======================================");
		
		int[][] result = new int[score.length][score[0].length + 2];

		for (int i = 0; i < score.length; i++) {

			for (int j = 0; j < score[i].length; j++) {

				result[i][j] = score[i][j];
				result[i][result[1].length - 2] += score[i][j];
				
				//result[result.length - 1][j] += score[i][j];
			}
			//result[result.length - 1][result[1].length - 1] += result[i][result[1].length - 1];
		}

		for (int i = 0; i < result.length; i++) {
			
				System.out.print(i+1);
				
				kor += result[i][0]; 
				eng += result[i][1]; // �� �� �� �� �ջ� ���� ��� �� 5�� ���ư���
				math += result[i][2];
				
			for (int j = 0; j < result[i].length; j++) {
				result[i][result[1].length - 1] = result[i][result[1].length -2]/3;
				System.out.printf("%7d", result[i][j]);
	
			}
			System.out.println();
			
			
		}
		System.out.println("======================================");
		System.out.print("���� - >" + "[����]"+kor+ "[����]"+eng + "[����]"+math );

// result[4][1]
	}

}
