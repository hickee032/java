package sec_verify.exam04;

public class Main {
	
	public static void main(String[] args) {		
		new TenColorButtonFrame(""); 
	}
}
